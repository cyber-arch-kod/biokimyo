// Kimyo darsliklari bazasi (7-11 sinflar)
window.CHEMISTRY_BOOKS = [
  {
    id: "chem-7",
    title: "7-sinf Kimyo (Dastlabki kimyoviy tushunchalar)",
    sinf: 7,
    icon: "🧪",
    color: "#8b5cf6",
    description: "Moddalar va ularning xossalari, atom-molekulyar ta'limot, kimyoviy elementlar",
    topics: [
      {
        id: "chem-7-1",
        title: "Moddalar, aralashmalar va toza moddalar",
        desc: "Fizikaviy va kimyoviy hodisalar, aralashmalarni ajratish usullari",
        visualType: "mixtures_separation",
        keyConcepts: ["Filtrlash", "Haydash", "Cho'ktirish", "Magnit bilan ajratish", "Toza modda"]
      },
      {
        id: "chem-7-2",
        title: "Kimyoviy elementlar, belgilar va valentlik",
        desc: "Atom tuzilishi, nisbiy atom massa, valentlik bo'yicha formula tuzish",
        visualType: "chemical_valency",
        keyConcepts: ["Valentlik", "Nisbiy atom massa (Ar)", "Kimyoviy belgi", "Indeks"]
      },
      {
        id: "chem-7-3",
        title: "Kislorod va Oksidlanish",
        desc: "Kislorodning olinishi, fizik-kimyoviy xossalari, yonish va oksidlar",
        visualType: "oxygen_combustion",
        keyConcepts: ["Oksidlanish", "Katalizator", "Kaliy permanganat", "Allotropiya (Ozon)"]
      },
      {
        id: "chem-7-4",
        title: "Vodorod va Kislotalar bilan tanishuv",
        desc: "Koinotdagi eng yengil element, Kipp apparati va metallar reaksiyalari",
        visualType: "hydrogen_reaction",
        keyConcepts: ["Kipp apparati", "Qaytaruvchi", "Portlovchi gaz", "Suv sintezi"]
      }
    ]
  },
  {
    id: "chem-8",
    title: "8-sinf Kimyo (Davriy qonun va noorganik sinflar)",
    sinf: 8,
    icon: "⚛️",
    color: "#6366f1",
    description: "Davriy sistema, kimyoviy bog'lanish turlari, oksidlar, asoslar, kislotalar, tuzlar",
    topics: [
      {
        id: "chem-8-1",
        title: "Davriy qonun va Atom tuzilishi",
        desc: "Kichik va katta davrlar, guruhlar, yadro zaryadi, proton, neytron, elektron konfiguratsiya",
        visualType: "periodic_table_atom",
        keyConcepts: ["Yadro zaryadi", "Elektron qavati", "Elektrontug'ishganlik", "Ionlanish energiyasi"]
      },
      {
        id: "chem-8-2",
        title: "Kimyoviy bog'lanish turlari",
        desc: "Kovalent (qutbli va qutbsiz), ion, metall va vodorod bog'lanishlar",
        visualType: "chemical_bonding",
        keyConcepts: ["Kovalent bog'", "Ion bog'", "Umumiy elektron jufti", "Kristall panjara"]
      },
      {
        id: "chem-8-3",
        title: "Noorganik birikmalarning asosiy sinflari",
        desc: "Oksidlar, asoslar, kislotalar va tuzlar — olinishi, xossalari, genetik bog'liqlik",
        visualType: "inorganic_classes",
        keyConcepts: ["Asosli oksid", "Kislotali oksid", "Amfoterlik", "Neytrallanish reaksiyasi"]
      }
    ]
  },
  {
    id: "chem-9",
    title: "9-sinf Kimyo (Elektrolitik dissotsilanish va Elementlar)",
    sinf: 9,
    icon: "⚗️",
    color: "#3b82f6",
    description: "Eritmalar, ion almashinish reaksiyalari, galogenlar, xalkogenlar va metallar",
    topics: [
      {
        id: "chem-9-1",
        title: "Elektrolitik dissotsilanish nazariyasi (EDN)",
        desc: "Elektrolitlar va noelektrolitlar, kationlar, anionlar, dissotsilanish darajasi",
        visualType: "dissociation_ions",
        keyConcepts: ["Elektrolit", "Dissotsilanish darajasi", "Ion tenglamalar", "Cho'kma va gaz ajralishi"]
      },
      {
        id: "chem-9-2",
        title: "Galogenlar (F, Cl, Br, I)",
        desc: "VII-A guruh elementlari, xlor, xlorid kislota va tuzlarining xususiyatlari",
        visualType: "halogens_group",
        keyConcepts: ["Xlorli ohak", "Kaliy xlorat (Bertolet tuzi)", "Kumush nitrat reaktivi", "Oksidlovchilik"]
      },
      {
        id: "chem-9-3",
        title: "Azot va Fosfor podguruhi",
        desc: "Azot, ammiak, nitrat kislota, fosfor allatropik shakllari va o'g'itlar",
        visualType: "nitrogen_cycle",
        keyConcepts: ["Ammiak", "Donorsimon-akseptor bog'", "Zarhal suv (Tsar aroq)", "Superfosfat"]
      },
      {
        id: "chem-9-4",
        title: "Metallar va ularning umumiy xossalari",
        desc: "Metall bog'lanish, metallarning kuchlanishlar qatori, korroziya va qotishmalar",
        visualType: "metals_reactivity",
        keyConcepts: ["Bekyetov qatori", "Korroziya", "Cho'yan va po'lat", "Amalgama"]
      }
    ]
  },
  {
    id: "chem-10",
    title: "10-sinf Kimyo (Organik kimyo: Uglevodorodlar va ularning hosilalari)",
    sinf: 10,
    icon: "🛢️",
    color: "#f59e0b",
    description: "Butlerov tuzilish nazariyasi, alkanlar, alkenlar, aromatik birikmalar, spirtlar",
    topics: [
      {
        id: "chem-10-1",
        title: "Organik birikmalarning kimyoviy tuzilish nazariyasi",
        desc: "A.M.Butlerov nazariyasi, izomeriya turlari, uglerodning gibridlanishi (sp3, sp2, sp)",
        visualType: "hybridization_isomers",
        keyConcepts: ["Izomeriya", "Gibridlanish", "Sigma va pi bog'lar", "Gomologik qator"]
      },
      {
        id: "chem-10-2",
        title: "To'yingan va to'yinmagan uglevodorodlar (Alkan, Alken, Alkin)",
        desc: "Metan qatori, etilen, atsetilen, birikish va polimerlanish reaksiyalari",
        visualType: "hydrocarbons_reactions",
        keyConcepts: ["Markovnikov qoidasi", "Bromli suv rangsizlanishi", "Polietilen", "Kucherov reaksiyasi"]
      },
      {
        id: "chem-10-3",
        title: "Aromatik uglevodorodlar (Arenlar: Benzol)",
        desc: "Benzol halqasi, Kekule formulasi, toluol, o'rin olish reaksiyalari",
        visualType: "benzene_ring",
        keyConcepts: ["Aromatiklik", "Kekule formulasi", "Nitrobenzol", "Zil-qora tutun"]
      },
      {
        id: "chem-10-4",
        title: "Kislorodli organik birikmalar: Spirtlar, Fenollar, Aldegidlar",
        desc: "Gidroksil guruhi, bir va ko'p atomli spirtlar (glitserin), kumush ko'zgu reaksiyasi",
        visualType: "alcohols_aldehydes",
        keyConcepts: ["Kumush ko'zgu", "Vodorod bog'lar", "Mis (II) gidroksid reaksiyasi", "Fenol"]
      }
    ]
  },
  {
    id: "chem-11",
    title: "11-sinf Kimyo (Murakkab organik birikmalar va Umumiy qonuniyatlar)",
    sinf: 11,
    icon: "💊",
    color: "#ec4899",
    description: "Karbon kislotalar, murakkab efirlar, yog'lar, uglevodlar, oqsillar va kimyoviy kinetika",
    topics: [
      {
        id: "chem-11-1",
        title: "Karbon kislotalar, murakkab efirlar va yog'lar",
        desc: "Sirka kislota, efirlanish reaksiyasi, sovun hosil bo'lishi va yog'lar gidrolizi",
        visualType: "esters_fats",
        keyConcepts: ["Efiranish", "Gidroliz", "Sovunlanish", "Stearin va olein kislotalar"]
      },
      {
        id: "chem-11-2",
        title: "Uglevodlar (Monosaxaridlar, Disaxaridlar, Polisaxaridlar)",
        desc: "Glyukoza, saxaroza, kraxmal va sellyuloza xossalari, yod reaksiyasi",
        visualType: "carbohydrates_starch",
        keyConcepts: ["Fotosintez mahsuloti", "Ko'k rang (yod)", "Glyukoza oksidlanishi", "Kraxmal"]
      },
      {
        id: "chem-11-3",
        title: "Aminokislotalar va Oqsillar",
        desc: "Amfoterlik, peptid bog'lanish, oqsillarning to'rt xil strukturasi, rangli reaksiyalar",
        visualType: "protein_structure",
        keyConcepts: ["Peptid bog'", "Biuret reaksiyasi", "Ksantoprotein reaksiyasi", "Denaturatsiya"]
      },
      {
        id: "chem-11-4",
        title: "Kimyoviy reaksiya tezligi va Kimyoviy muvozanat",
        desc: "Vant-Goff qoidasi, Le-Shatelye prinsipi, harorat, bosim va konsentratsiya ta'siri",
        visualType: "equilibrium_lechatelier",
        keyConcepts: ["Le-Shatelye prinsipi", "Vant-Goff qoidasi", "Muvozanat siljishi", "Katalizator"]
      }
    ]
  }
];
