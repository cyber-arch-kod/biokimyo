// Asosiy ilova kontrolleri va navigatsiyasi
window.App = {
  currentSubject: 'bio', // 'bio' yoki 'chem'
  currentBook: null,
  currentTopic: null,

  init: function() {
    this.bindEvents();
    window.UserProgress.updateHeaderStats();
    this.renderBooks(this.currentSubject);
  },

  bindEvents: function() {
    // Fan almashtirish tablari
    const tabBio = document.getElementById('tab-bio');
    const tabChem = document.getElementById('tab-chem');

    if (tabBio) {
      tabBio.onclick = () => {
        this.switchSubject('bio');
      };
    }
    if (tabChem) {
      tabChem.onclick = () => {
        this.switchSubject('chem');
      };
    }
  },

  switchSubject: function(subject) {
    this.currentSubject = subject;
    const tabBio = document.getElementById('tab-bio');
    const tabChem = document.getElementById('tab-chem');

    if (subject === 'bio') {
      tabBio.className = "flex-1 py-3 text-center font-bold text-sm rounded-2xl bg-emerald-600 text-white shadow-md shadow-emerald-600/30 transition-all";
      tabChem.className = "flex-1 py-3 text-center font-bold text-sm rounded-2xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all";
    } else {
      tabChem.className = "flex-1 py-3 text-center font-bold text-sm rounded-2xl bg-indigo-600 text-white shadow-md shadow-indigo-600/30 transition-all";
      tabBio.className = "flex-1 py-3 text-center font-bold text-sm rounded-2xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all";
    }

    this.renderBooks(subject);
    this.showView('view-books');
  },

  showView: function(viewId) {
    const views = ['view-books', 'view-topics', 'view-topic-detail', 'view-quiz', 'view-game'];
    views.forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        if (id === viewId) {
          el.classList.remove('hidden');
        } else {
          el.classList.add('hidden');
        }
      }
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  },

  // 1. Kitoblar ro'yxatini chiqarish
  renderBooks: function(subject) {
    const container = document.getElementById('books-list');
    if (!container) return;

    const books = subject === 'bio' ? window.BIOLOGY_BOOKS : window.CHEMISTRY_BOOKS;
    let html = '';

    books.forEach(b => {
      let totalQuestions = b.topics.length * 50; // har bir mavzuda 50 ta quiz
      let completedTopicsCount = 0;
      let totalStars = 0;

      b.topics.forEach(t => {
        const stats = window.UserProgress.getTopicStats(t.id);
        if (stats.bestPercent >= 50) completedTopicsCount++;
        totalStars += stats.stars;
      });

      html += `
        <div onclick="App.openBook('${b.id}')" 
             class="group relative bg-white dark:bg-slate-800 rounded-3xl p-5 shadow-sm hover:shadow-xl border border-slate-100 dark:border-slate-700/60 transition-all duration-300 cursor-pointer active:scale-[0.98]">
          <div class="flex items-start gap-4">
            <div class="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl shadow-inner" style="background-color: ${b.color}15; color: ${b.color};">
              ${b.icon}
            </div>
            <div class="flex-1">
              <div class="flex items-center justify-between">
                <span class="text-xs font-extrabold uppercase tracking-wider px-2.5 py-0.5 rounded-full" style="background-color: ${b.color}20; color: ${b.color};">
                  ${b.sinf}-sinf
                </span>
                <span class="text-xs font-semibold text-amber-500 flex items-center gap-1">
                  ⭐ ${totalStars} yulduz
                </span>
              </div>
              <h3 class="text-base sm:text-lg font-bold text-slate-900 dark:text-white mt-1 group-hover:text-emerald-600 transition-colors">
                ${b.title}
              </h3>
              <p class="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                ${b.description}
              </p>
            </div>
          </div>

          <!-- Pastki ko'rsatkichlar -->
          <div class="mt-4 pt-3 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between text-xs text-slate-400 font-medium">
            <span>📚 ${b.topics.length} ta asosiy mavzu</span>
            <span class="text-emerald-600 dark:text-emerald-400 font-bold">⚡ ${totalQuestions}+ test</span>
          </div>
        </div>
      `;
    });

    container.innerHTML = html;
  },

  // 2. Kitob ichidagi mavzularni ochish
  openBook: function(bookId) {
    const books = this.currentSubject === 'bio' ? window.BIOLOGY_BOOKS : window.CHEMISTRY_BOOKS;
    const book = books.find(b => b.id === bookId);
    if (!book) return;

    this.currentBook = book;
    document.getElementById('topics-book-title').innerText = book.title;
    document.getElementById('topics-book-desc').innerText = book.description;

    const container = document.getElementById('topics-list');
    let html = '';

    book.topics.forEach((t, idx) => {
      const stats = window.UserProgress.getTopicStats(t.id);
      const starIcons = "⭐".repeat(stats.stars) + "☆".repeat(3 - stats.stars);

      html += `
        <div onclick="App.showTopicView('${t.id}')" 
             class="bg-white dark:bg-slate-800 rounded-3xl p-5 shadow-sm hover:shadow-lg border border-slate-100 dark:border-slate-700/60 transition-all cursor-pointer active:scale-[0.98]">
          <div class="flex items-start justify-between gap-3">
            <div class="flex items-center gap-3">
              <span class="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center font-black text-xs text-slate-600 dark:text-slate-300">
                ${idx + 1}
              </span>
              <div>
                <h4 class="text-sm sm:text-base font-bold text-slate-900 dark:text-white leading-snug">
                  ${t.title}
                </h4>
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  ${t.desc}
                </p>
              </div>
            </div>
            <div class="text-right flex-shrink-0">
              <span class="text-xs text-amber-500 font-bold">${starIcons}</span>
              ${stats.bestPercent > 0 ? `<span class="block text-[11px] font-bold text-emerald-600">${stats.bestPercent}%</span>` : ''}
            </div>
          </div>

          <div class="flex flex-wrap gap-1.5 mt-3 pt-3 border-t border-slate-100 dark:border-slate-700/50">
            ${t.keyConcepts ? t.keyConcepts.map(c => `<span class="text-[11px] px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-700/80 text-slate-600 dark:text-slate-300">${c}</span>`).join('') : ''}
          </div>
        </div>
      `;
    });

    container.innerHTML = html;
    this.showView('view-topics');
  },

  // 3. Alohida mavzuning bosh sahifasi (Quiz, O'yinlar, Rasmli sxema)
  showTopicView: function(topicId) {
    const books = this.currentSubject === 'bio' ? window.BIOLOGY_BOOKS : window.CHEMISTRY_BOOKS;
    let topic = null;
    let book = null;

    for (const b of books) {
      const found = b.topics.find(t => t.id === topicId);
      if (found) {
        topic = found;
        book = b;
        break;
      }
    }

    if (!topic) return;
    this.currentTopic = topic;
    this.currentBook = book;

    document.getElementById('detail-topic-title').innerText = topic.title;
    document.getElementById('detail-topic-desc').innerText = topic.desc;

    // Rasmli interaktiv sxemani render qilish
    const visualBox = document.getElementById('topic-visual-box');
    const visualAsset = window.VISUAL_ASSETS[topic.visualType];

    if (visualAsset) {
      visualBox.innerHTML = `
        <div class="bg-gradient-to-br from-slate-50 to-emerald-50/30 dark:from-slate-900 dark:to-slate-800 p-4 sm:p-6 rounded-3xl border border-emerald-100 dark:border-slate-700">
          <div class="flex items-center justify-between mb-2">
            <span class="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
              <span>🖼️</span> Interaktiv Rasmli O'rganish
            </span>
            <span class="text-xs text-slate-400">Nuqtalarni bosing 👇</span>
          </div>
          <h4 class="text-sm sm:text-base font-bold text-slate-800 dark:text-white mb-3">
            ${visualAsset.title}
          </h4>
          
          <!-- SVG rasmi -->
          <div class="my-3 overflow-hidden rounded-2xl bg-white dark:bg-slate-950/60 p-2 border border-slate-200 dark:border-slate-700 shadow-inner">
            ${visualAsset.svg}
          </div>

          <!-- Bosinganda ma'lumot ko'rinadigan blok -->
          <div id="visual-info-card" class="mt-4 p-4 rounded-2xl bg-white dark:bg-slate-800 border-2 border-emerald-500 shadow-md">
            <p class="text-xs text-emerald-600 font-bold uppercase" id="visual-part-title">💡 Sinab ko'ring</p>
            <p class="text-sm font-semibold text-slate-700 dark:text-slate-200 mt-1" id="visual-part-desc">
              Rasmdagi a'zolar yoki organoidlar ustiga bosing, ularning vazifasi shu yerda ochiladi!
            </p>
          </div>
        </div>
      `;

      // Interaktiv qismlarga klik qo'shish
      setTimeout(() => {
        const parts = visualBox.querySelectorAll('.interactive-part');
        parts.forEach(el => {
          el.addEventListener('click', (e) => {
            const partKey = el.getAttribute('data-part');
            const info = visualAsset.parts[partKey];
            if (info) {
              document.getElementById('visual-part-title').innerText = "📌 " + info.name;
              document.getElementById('visual-part-desc').innerText = info.func;
              
              // Animatsiya effekti
              const infoCard = document.getElementById('visual-info-card');
              infoCard.classList.add('ring-4', 'ring-emerald-400/40');
              setTimeout(() => infoCard.classList.remove('ring-4', 'ring-emerald-400/40'), 400);
            }
          });
        });
      }, 50);

    } else {
      visualBox.innerHTML = `
        <div class="p-6 bg-slate-50 dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 text-center">
          <span class="text-4xl mb-2 block">📖</span>
          <p class="text-sm font-bold text-slate-700 dark:text-slate-300">Darslik konspekti va kalit so'zlar</p>
          <div class="flex flex-wrap justify-center gap-2 mt-3">
            ${topic.keyConcepts.map(c => `<span class="px-3 py-1 bg-white dark:bg-slate-800 rounded-full text-xs font-semibold text-emerald-600 border border-emerald-200 dark:border-slate-700">${c}</span>`).join('')}
          </div>
        </div>
      `;
    }

    this.showView('view-topic-detail');
  },

  // 4. Test sinovini boshlash (10, 25 yoki to'liq 50 ta)
  startQuizMode: function(count) {
    if (!this.currentTopic) return;
    this.showView('view-quiz');
    window.QuizEngine.startQuiz(this.currentTopic.id, count);
  },

  // 5. Fleshkartlar rejimini ochish
  openFlashcards: function() {
    if (!this.currentTopic) return;
    this.showView('view-game');
    document.getElementById('game-title').innerText = "🎴 Fleshkartlar: " + this.currentTopic.title;
    window.GameSystem.initFlashcards('game-content-box', this.currentTopic.id);
  },

  // 6. "Juftini top" o'yinini ochish
  openMatchingGame: function() {
    this.showView('view-game');
    document.getElementById('game-title').innerText = "🧩 Juftini top o'yini (" + (this.currentSubject === 'bio' ? 'Biologiya' : 'Kimyo') + ")";
    window.GameSystem.initMatchingGame('game-content-box', this.currentSubject);
  }
};

// Ilova yuklanganda ishga tushirish
document.addEventListener('DOMContentLoaded', () => {
  window.App.init();
});
