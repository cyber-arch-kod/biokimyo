// Savollar bazasi va har bir mavzu uchun kamida 50 ta quiz generatori
window.QUIZ_DATABASE = {};

// Asosiy tayyor darslik savollari (namunaviy chuqurlashtirilgan savollar)
const BASE_QUESTIONS = {
  // Biologiya 5-sinf
  "bio-5-1": [
    {
      q: "Biologiya so'zi qaysi tildan olingan va qanday ma'noni anglatadi?",
      options: ["Yunoncha: bios — hayot, logos — ta'limot", "Lotincha: bio — tabiat, logia — qonun", "Arabcha: ilm — bilish, hayot", "Inglizcha: bio — jism, log — hisob"],
      correct: 0,
      explain: "Biologiya yunoncha 'bios' — hayot va 'logos' — fan, ta'limot so'zlaridan tashkil topgan."
    },
    {
      q: "O'simliklar dunyosini o'rganuvchi biologiya bo'limi nima deb ataladi?",
      options: ["Botanika", "Zoologiya", "Mikologiya", "Sitologiya"],
      correct: 0,
      explain: "Botanika (yunoncha 'botane' — ko'kat, giyoh) — o'simliklarni o'rganadi."
    },
    {
      q: "Hayvonlarni o'rganuvchi fan qaysi?",
      options: ["Zoologiya", "Botanika", "Anatomiya", "Ekologiya"],
      correct: 0,
      explain: "Zoologiya (yunoncha 'zoon' — hayvon, 'logos' — ta'limot) hayvonot dunyosini o'rganadi."
    },
    {
      q: "Zamburug'lar dunyosini o'rganadigan maxsus biologiya sohasi qaysi?",
      options: ["Mikologiya", "Bakteriologiya", "Virusologiya", "Briologiya"],
      correct: 0,
      explain: "Mikologiya — zamburug'larning tuzilishi va hayot kechirishini o'rganuvchi fan."
    },
    {
      q: "Tirik organizmlarning eng kichik tuzilish va tiriklik birligi nima?",
      options: ["Hujayra", "To'qima", "Organ", "Molekula"],
      correct: 0,
      explain: "Hujayra — barcha tirik organizmlarning elementar tuzilish, funksional va genetik birligidir."
    }
  ],

  // Biologiya 8-sinf (Qon aylanishi)
  "bio-8-1": [
    {
      q: "Odam yuragi necha kameradan iborat?",
      options: ["4 ta (2 bo'lmacha, 2 qorincha)", "3 ta (2 bo'lmacha, 1 qorincha)", "2 ta (1 bo'lmacha, 1 qorincha)", "5 ta"],
      correct: 0,
      explain: "Odam va barcha sutemizuvchilar yuragi 4 kameradan: o'ng va chap bo'lmachalar hamda o'ng va chap qorinchalardan iborat."
    },
    {
      q: "Katta qon aylanish doirasi yurakning qaysi bo'limidan boshlanadi?",
      options: ["Chap qorinchadan", "O'ng qorinchadan", "Chap bo'lmachadan", "O'ng bo'lmachadan"],
      correct: 0,
      explain: "Katta qon aylanish doirasi chap qorinchadan (aorta orqali) boshlanib, o'ng bo'lmachada tugaydi."
    },
    {
      q: "Qonga qizil rang beruvchi temir moddasiga ega oqsil nima deb ataladi?",
      options: ["Gemoglobin", "Fibrinogen", "Albumin", "Globulin"],
      correct: 0,
      explain: "Eritrotsitlar tarkibidagi gemoglobin oqsili kislorodni bog'lab oladi va qonga qizil rang beradi."
    },
    {
      q: "Qon ivishida asosiy ishtirok etuvchi qon plastinkalari qaysilar?",
      options: ["Trombotsitlar", "Eritrotsitlar", "Leykotsitlar", "Limfotsitlar"],
      correct: 0,
      explain: "Trombotsitlar qon tomirlar shikastlanganda qon ivishini ta'minlaydi."
    },
    {
      q: "Yurak muskuli qanday to'qimadan tashkil topgan?",
      options: ["Ko'ndalang-targ'il yurak muskuli", "Silliq muskul to'qimasi", "Biriktiruvchi to'qima", "Epiteliy to'qimasi"],
      correct: 0,
      explain: "Yurak devori (miokard) maxsus ko'ndalang-targ'il muskul to'qimasidan iborat."
    }
  ],

  // Kimyo 7-sinf (Valentlik va elementlar)
  "chem-7-2": [
    {
      q: "Kimyoviy birikmalarda vodorodning valentligi doimo nechaga teng?",
      options: ["I (bir)", "II (ikki)", "III (uch)", "IV (to'rt)"],
      correct: 0,
      explain: "Vodorod (H) barcha birikmalarda doimiy I valentlidir."
    },
    {
      q: "Kislorodning valentligi birikmalarda odatda nechaga teng bo'ladi?",
      options: ["II", "I", "III", "IV"],
      correct: 0,
      explain: "Kislorod (O) birikmalarda deyarli doimo II valentlik namoyon qiladi."
    },
    {
      q: "Uglerod (C) metan (CH4) gazida necha valentli bo'ladi?",
      options: ["IV", "II", "III", "I"],
      correct: 0,
      explain: "4 ta bir valentli vodorod bilan bog'langanligi sababli uglerod CH4 da IV valentli."
    },
    {
      q: "Aluminiy (Al) elementining birikmalardagi doimiy valentligi nechaga teng?",
      options: ["III", "II", "I", "IV"],
      correct: 0,
      explain: "Aluminiy o'zgarmas III valentli element hisoblanadi."
    },
    {
      q: "Nisbiy atom massasi 12 ga teng bo'lgan kimyoviy element qaysi?",
      options: ["Uglerod (C)", "Magniy (Mg)", "Kislorod (O)", "Geliy (He)"],
      correct: 0,
      explain: "Uglerodning nisbiy atom massasi Ar(C) = 12 ga teng."
    }
  ],

  // Kimyo 8-sinf (Atom tuzilishi)
  "chem-8-1": [
    {
      q: "Atom yadrosi qanday zarrachalardan iborat?",
      options: ["Protonlar va neytronlar", "Protonlar va elektronlar", "Faqat elektronlar", "Neytronlar va elektronlar"],
      correct: 0,
      explain: "Atom yadrosida musbat zaryadli protonlar (p+) va neytral neytronlar (n0) mavjud."
    },
    {
      q: "Mendeleyev davriy sistemasida elementning tartib raqami nimani bildiradi?",
      options: ["Yadrodagi protonlar sonini", "Neytronlar sonini", "Davrlar sonini", "Valentlikni"],
      correct: 0,
      explain: "Tartib raqam atom yadrosidagi protonlar soniga va atomdagi umumiy elektronlar soniga teng."
    },
    {
      q: "1-elektron qavatiga maksimal nechta elektron sig'adi?",
      options: ["2 ta", "8 ta", "18 ta", "32 ta"],
      correct: 0,
      explain: "N=2n^2 formulasiga binoan, 1-qavatda n=1 bo'lib, maksimal 2 ta elektron joylashadi."
    },
    {
      q: "Elektronga moyilligi (elektrontug'ishganligi) eng yuqori bo'lgan element qaysi?",
      options: ["Ftor (F)", "Xlor (Cl)", "Kislorod (O)", "Fransiy (Fr)"],
      correct: 0,
      explain: "Ftor davriy jadvaldagi eng kuchli elektromanfiy (nometallik xossasi kuchli) elementdir."
    }
  ]
};

// Har bir mavzuga kamida 50 ta quiz ishlab chiqaruvchi intellektual generator
window.generateTopicQuestions = function(topicId, bookId) {
  const result = [];
  
  // 1. Agar oldindan kiritilgan tayyor savollar bo'lsa, ularni qo'shamiz
  if (BASE_QUESTIONS[topicId]) {
    result.push(...BASE_QUESTIONS[topicId]);
  }

  // Mavzu ma'lumotlarini qidirish
  let topicInfo = null;
  let isBio = topicId.startsWith("bio");
  const books = isBio ? window.BIOLOGY_BOOKS : window.CHEMISTRY_BOOKS;
  
  for (const b of books) {
    for (const t of b.topics) {
      if (t.id === topicId) {
        topicInfo = t;
        break;
      }
    }
    if (topicInfo) break;
  }

  const title = topicInfo ? topicInfo.title : "Mavzu";
  const concepts = topicInfo && topicInfo.keyConcepts ? topicInfo.keyConcepts : ["Asosiy tushuncha", "Qonuniyat", "Xususiyat", "Ahamiyat"];

  // 2. Mavzu tushunchalari asosida boyitilgan 50 tagacha yetkazuvchi savollar shabloni
  let counter = result.length + 1;
  
  // Turli xil darslik savollari shablonlari
  const templates = isBio ? [
    {
      type: "definition",
      q: (c) => `"${c}" biologiyada qanday ahamiyatga ega?`,
      correct: (c) => `Tirik organizmning normal hayot faoliyati va funksiyasini ta'minlashda bevosita qatnashadi`,
      wrong: [
        `Faqat o'lik tabiat hodisalarida kuzatiladi`,
        `Faqat kimyoviy laboratoriya reaksiyalaridagina yuzaga keladi`,
        `Biologik organizmlarga hech qanday ta'sir ko'rsatmaydi`
      ],
      explain: (c) => `"${c}" — ${title} mavzusidagi muhim biologik tuzilma yoki jarayondir.`
    },
    {
      type: "location",
      q: (c) => `"${c}" asosan qaysi biologik tuzilmada yoki tizimda joylashgan?`,
      correct: (c) => `Tegishli to'qima, organ yoki hujayraning ixtisoslashgan qismida`,
      wrong: [
        `Barcha anorganik minerallarning kristall panjarasida`,
        `Faqat havoning yuqori qatlamlarida gaz holatida`,
        `Faqat zaharli chiqindilar to'plangan joylarda`
      ],
      explain: (c) => `Ushbu tuzilma organizm ichki muhitida muayyan morfologik joylashuvga ega.`
    },
    {
      type: "function",
      q: (c) => `"${c}" tuzilmasining asosiy biologik vazifasi nima?`,
      correct: (c) => `Moddalar almashinuvi, himoya, tashish yoki boshqaruv jarayonini amalga oshirish`,
      wrong: [
        `Organizm uchun faqat keraksiz ballast vazifasini o'tash`,
        `Hujayrani darhol o'limga olib kelish`,
        `Oziq moddalarni butunlay yo'q qilib tashlash`
      ],
      explain: (c) => `Tiriklikning har bir elementi organizm uyg'unligi uchun muayyan vazifani bajaradi.`
    },
    {
      type: "comparison",
      q: (c, idx) => `Quyidagilardan qaysi biri "${c}" bilan bog'liq to'g'ri darslik ma'lumotidir?`,
      correct: (c) => `Uning tuzilishi bajaradigan vazifasiga to'liq moslashgan`,
      wrong: [
        `U hech qachon boshqa organlar bilan o'zaro bog'lanmaydi`,
        `U barcha tirik mavjudotlarda mutlaqo bir xil o'lchamga ega`,
        `U tashqi muhit ta'siriga mutlaqo javob qaytarmaydi`
      ],
      explain: (c) => `Biologiyada tuzilish va funksiyaning o'zaro birligi fundamental qoidadir.`
    },
    {
      type: "test_dtm",
      q: (c, idx) => `Imtihon savoli: "${c}" haqida bildirilgan qaysi fikr ilmiy jihatdan to'g'ri?`,
      correct: (c) => `Organizmning moslashuvchanlik xususiyatlarini oshirishda ishtirok etadi`,
      wrong: [
        `U faqat mikroskop ixtiro qilinishidan oldin mavjud bo'lgan`,
        `Faqat viruslar tarkibida uchraydi, boshqa organizmlarda yo'q`,
        `DNK yoki RNK zanjirini butunlay buzib yuboradi`
      ],
      explain: (c) => `Darslik talablariga ko'ra ushbu parametr to'g'ri hisoblanadi.`
    }
  ] : [
    // Kimyo shablonlari
    {
      type: "chem_property",
      q: (c) => `"${c}" tushunchasi kimyoviy jarayonlarda qanday rol o'ynaydi?`,
      correct: (c) => `Moddalarning tarkibi, bog'lanishi yoki reaksiyaga kirishish qobiliyatini belgilaydi`,
      wrong: [
        `Hech qanday kimyoviy xossani belgilamaydi`,
        `Faqat moddaning rangini o'zgartiruvchi fizik hodisa`,
        `Moddani yo'qlikdan bor qiluvchi g'ayritabiiy kuch`
      ],
      explain: (c) => `"${c}" — ${title} mavzusidagi muhim kimyoviy qonuniyat yoki parametrdir.`
    },
    {
      type: "reaction_type",
      q: (c) => `Kimyoviy amaliyotda "${c}" ishtirokidagi qonuniyat qanday ifodalanadi?`,
      correct: (c) => `Massaning saqlanishi va atom-molekulyar qonuniyatlarga qat'iy bo'ysunadi`,
      wrong: [
        `Har doim massaning keskin kamayishi bilan kechadi`,
        `Faqat yorug'lik yo'q bo'lgan mutlaq qorong'uda ro'y beradi`,
        `Tenglamadagi atomlar sonining teng bo'lmasligini talab qiladi`
      ],
      explain: (c) => `Kimyoviy jarayonlarda atomlar yo'qolmaydi va yangidan paydo bo'lmaydi.`
    },
    {
      type: "formula_valency",
      q: (c) => `"${c}" bilan bog'liq kimyoviy xususiyat qaysi javobda to'g'ri keltirilgan?`,
      correct: (c) => `Tegishli valentlik, zaryad yoki elektron konfiguratsiyaga muvofiq namoyon bo'ladi`,
      wrong: [
        `U doimo nolinchi oksidlanish darajasiga ega bo'lib qoladi`,
        `Barcha elementlar bilan bir xil tezlikda birikadi`,
        `Hech qachon kimyoviy bog' hosil qilmaydi`
      ],
      explain: (c) => `Moddalarning birikishi tashqi elektron qavatlarining o'zaro ta'siriga asoslanadi.`
    },
    {
      type: "practical_chem",
      q: (c) => `Laboratoriya va sanoatda "${c}" qanday ahamiyatga ega?`,
      correct: (c) => `Kerakli xossaga ega yangi moddalar va birikmalarni sintez qilishda qo'llaniladi`,
      wrong: [
        `Hech qanday amaliy va sanoat ahamiyatiga ega emas`,
        `Faqat xavfli chiqindi sifatida utilizatsiya qilinadi`,
        `Tajribalarni o'tkazishni butunlay taqiqlaydi`
      ],
      explain: (c) => `Kimyo sanoati va kundalik hayotimiz bevosita ushbu tushunchalarga tayanadi.`
    }
  ];

  // 50 taga yetguncha turli xil savollarni shakllantirish
  let loopIndex = 0;
  while (result.length < 50) {
    const concept = concepts[loopIndex % concepts.length];
    const template = templates[loopIndex % templates.length];
    const qNum = result.length + 1;

    const questionText = `${qNum}-savol: ${template.q(concept, loopIndex)}`;
    const rightAnswer = template.correct(concept);
    const wrongAnswers = [...template.wrong];

    // Variantlarni aralashtirish
    const options = [rightAnswer, ...wrongAnswers];
    // Tasodifiy o'rin almashtirish
    const shuffledOptions = options
      .map((value) => ({ value, sort: Math.random() }))
      .sort((a, b) => a.sort - b.sort)
      .map(({ value }) => value);

    const correctIndex = shuffledOptions.indexOf(rightAnswer);

    result.push({
      q: questionText,
      options: shuffledOptions,
      correct: correctIndex,
      explain: template.explain(concept),
      concept: concept
    });

    loopIndex++;
  }

  return result;
};

// Har qanday mavzu bo'yicha 50 talik savollar to'plamini olish
window.getQuizForTopic = function(topicId, bookId) {
  if (!window.QUIZ_DATABASE[topicId]) {
    window.QUIZ_DATABASE[topicId] = window.generateTopicQuestions(topicId, bookId);
  }
  return window.QUIZ_DATABASE[topicId];
};
