// Biologiya darsliklari bazasi (5-11 sinflar)
window.BIOLOGY_BOOKS = [
  {
    id: "bio-5",
    title: "5-sinf Biologiya (Botanika asoslari)",
    sinf: 5,
    icon: "🌱",
    color: "#10b981",
    description: "Tirik tabiat, o'simliklar dunyosi va biologik asosiy tushunchalar",
    topics: [
      {
        id: "bio-5-1",
        title: "Biologiya — tirik tabiat haqidagi fan",
        desc: "Biologiya fanining sohalari, tirik organizmlarning asosiy xususiyatlari",
        visualType: "cell_intro",
        keyConcepts: ["Oziqlanish", "Nafas olish", "Ko'payish", "O'sish va rivojlanish", "Moddalar almashinuvi"]
      },
      {
        id: "bio-5-2",
        title: "Kattalashtiruvchi asboblar: Lupa va Mikroskop",
        desc: "Optik asboblar, mikroskopning tuzilishi va ishlash qoidalari",
        visualType: "microscope",
        keyConcepts: ["Okulyar", "Obyektiv", "Tubus", "Predmet stoli", "Ko'zgu"]
      },
      {
        id: "bio-5-3",
        title: "O'simlik hujayrasining tuzilishi",
        desc: "Qobiq, sitoplazma, yadro, vakuola va plastidalar",
        visualType: "plant_cell",
        keyConcepts: ["Xloroplast", "Vakuola", "Hujayra po'sti", "Yadro", "Sitoplazma"]
      },
      {
        id: "bio-5-4",
        title: "O'simlik to'qimalari",
        desc: "Hosil qiluvchi, asosiy, qoplovchi, o'tkazuvchi va mexanik to'qimalar",
        visualType: "plant_tissues",
        keyConcepts: ["Ksilema", "Floema", "Kambiy", "Parenxima", "Epidermis"]
      },
      {
        id: "bio-5-5",
        title: "Ildiz va uning zonalari",
        desc: "Ildiz turlari, ildiz tizimlari va ichki mikroskopik zonalari",
        visualType: "root_zones",
        keyConcepts: ["O'q ildiz", "Popuk ildiz", "Ildiz qinchasi", "Bo'linish zonasi", "So'ruvchi zona"]
      }
    ]
  },
  {
    id: "bio-6",
    title: "6-sinf Biologiya (O'simliklar anatomiyasi va morfologiyasi)",
    sinf: 6,
    icon: "🌸",
    color: "#059669",
    description: "Gulli o'simliklarning vegetativ va generativ organlari, fotosintez",
    topics: [
      {
        id: "bio-6-1",
        title: "Poya va novdaning ichki tuzilishi",
        desc: "Po'stloq, kambiy, yog'ochlik va o'zak qismlari",
        visualType: "stem_structure",
        keyConcepts: ["Po'kak", "Kambiy", "Floema elaksimon naylari", "Yillik halqalar"]
      },
      {
        id: "bio-6-2",
        title: "Barg va fotosintez jarayoni",
        desc: "Barg anatomiyasi, og'izchalar va yorug'likda ozuqa sintezi",
        visualType: "photosynthesis",
        keyConcepts: ["Xlorofill", "Og'izcha", "Uglerod angidrid", "Glyukoza", "Kislorod ajralishi"]
      },
      {
        id: "bio-6-3",
        title: "Gul tuzilishi va formulasi",
        desc: "Gulqo'rg'on, changchi, urug'chi va changlanish turlari",
        visualType: "flower_anatomy",
        keyConcepts: ["Changchi", "Urug'chi", "Tojbarg", "Kosachabarg", "Tuguncha"]
      },
      {
        id: "bio-6-4",
        title: "Mevalar va urug'lar",
        desc: "Quruq va sersuv mevalar, bir va ikki urug'pallali urug' tuzilishi",
        visualType: "seed_anatomy",
        keyConcepts: ["Murtak", "Endosperm", "Urug'pallasi", "Po'st"]
      }
    ]
  },
  {
    id: "bio-7",
    title: "7-sinf Biologiya (Zoologiya — Hayvonot olami)",
    sinf: 7,
    icon: "🦅",
    color: "#d97706",
    description: "Bir hujayralilar, umurtqasizlar va umurtqali hayvonlar anatomiyasi",
    topics: [
      {
        id: "bio-7-1",
        title: "Bir hujayrali sodda hayvonlar",
        desc: "Oddiy amyoba, yashil evglena, tufelka-infuzoriya",
        visualType: "protozoa",
        keyConcepts: ["Soxta oyoqlar", "Xivchin", "Xiplar", "Qisqaruvchi vakuola"]
      },
      {
        id: "bio-7-2",
        title: "Bo'g'imoyoqlilar tipi",
        desc: "Qisqichbaqasimonlar, o'rgimchaksimonlar va hasharotlar",
        visualType: "arthropoda",
        keyConcepts: ["Xitin qobiq", "Fasetkali ko'z", "Traxeyalar", "Mo'ylovlar"]
      },
      {
        id: "bio-7-3",
        title: "Baliqlar va suvda ham quruqlikda yashovchilar",
        desc: "Suzgich pufagi, yon chiziq, 2 va 3 kamerali yurak",
        visualType: "fish_amphibian",
        keyConcepts: ["Jabralar", "Yon chiziq", "Suzgich pufagi", "Kloaka"]
      },
      {
        id: "bio-7-4",
        title: "Qushlar va sutemizuvchilar",
        desc: "Issiqqonlilik, 4 kamerali yurak, qon aylanish doiralari",
        visualType: "vertebrate_circulation",
        keyConcepts: ["Ikki karra nafas olish", "Diafragma", "O'ng/chap aorta yoyi"]
      }
    ]
  },
  {
    id: "bio-8",
    title: "8-sinf Biologiya (Odam va uning salomatligi)",
    sinf: 8,
    icon: "🫀",
    color: "#dc2626",
    description: "Inson tanasining anatomiyasi, fiziologiyasi va gigiyenasi",
    topics: [
      {
        id: "bio-8-1",
        title: "Qon va qon aylanish sistemasi",
        desc: "Yurak tuzilishi, katta va kichik qon aylanish doiralari, qon hujayralari",
        visualType: "heart_anatomy",
        keyConcepts: ["Eritrotsitlar", "Leykotsitlar", "Trombotsitlar", "Aorta", "Gemoglobin"]
      },
      {
        id: "bio-8-2",
        title: "Nerv sistemasi va miya",
        desc: "Bosh miya bo'limlari, orqa miya va neyron tuzilishi",
        visualType: "brain_neuron",
        keyConcepts: ["Dendrit", "Akson", "Sinaps", "Uzunchoq miya", "Miyacha"]
      },
      {
        id: "bio-8-3",
        title: "Nafas olish va ayirish sistemalari",
        desc: "O'pkalar, alveolalar, buyrak nefronlari va siydik hosil bo'lishi",
        visualType: "kidney_lungs",
        keyConcepts: ["Alveola", "Nefron", "Malpigi koptokchasi", "Birlamchi siydik"]
      },
      {
        id: "bio-8-4",
        title: "Hazm qilish sistemasi va vitaminlar",
        desc: "Me'da, jigar, ichaklar, fermentlar va oziq moddalar parchalanishi",
        visualType: "digestive_system",
        keyConcepts: ["Pepsin", "Tripsin", "Safro", "Amilaza", "Villilar"]
      }
    ]
  },
  {
    id: "bio-9",
    title: "9-sinf Biologiya (Sitologiya va Genetika asoslari)",
    sinf: 9,
    icon: "🧬",
    color: "#7c3aed",
    description: "Hujayra nazariyasi, biosintez, mitoz, meyoz va irsiyat qonunlari",
    topics: [
      {
        id: "bio-9-1",
        title: "Hujayraning kimyoviy tarkibi va oqsillar",
        desc: "Biopolimerlar, aminokislotalar, ATF va nuklein kislotalar",
        visualType: "dna_protein",
        keyConcepts: ["Peptid bog'", "Nukleotid", "ATF", "Komplementarlik"]
      },
      {
        id: "bio-9-2",
        title: "Mitoz va Meyoz bo'linishlari",
        desc: "Hujayra sikli, profaza, metafaza, anafaza, telofaza va krossingover",
        visualType: "cell_division",
        keyConcepts: ["Xromosoma", "Xromatida", "Sentromera", "Krossingover", "Reduksion bo'linish"]
      },
      {
        id: "bio-9-3",
        title: "Mendel qonunlari va genetika",
        desc: "Monoduragay, diduragay, to'liq va to'liqsiz dominantlik",
        visualType: "mendel_genetics",
        keyConcepts: ["Genotip", "Fenotip", "Allel genlar", "Geterozigota", "Gomozigota"]
      }
    ]
  },
  {
    id: "bio-10",
    title: "10-sinf Biologiya (Molekulyar biologiya va Biologik jarayonlar)",
    sinf: 10,
    icon: "🔬",
    color: "#2563eb",
    description: "Transkripsiya, translyatsiya, energetik almashinuv, fotosintez fazalari",
    topics: [
      {
        id: "bio-10-1",
        title: "Energetik almashinuv bosqichlari",
        desc: "Tayyorgarlik, glikoliz va kislorodli (mitoxondriya) bosqichlar, ATF hisobi",
        visualType: "cellular_respiration",
        keyConcepts: ["Glikoliz", "Krebs sikli", "Sut kislotasi", "38 ATF", "Pirouzum kislotasi"]
      },
      {
        id: "bio-10-2",
        title: "Oqsil biosintezi: Transkripsiya va Translyatsiya",
        desc: "iRNK, tRNK, ribosoma, genetik kod va kodon-antikodon",
        visualType: "protein_synthesis",
        keyConcepts: ["Kodon", "Antikodon", "Transkripsiya", "Translyatsiya", "Matritsa"]
      }
    ]
  },
  {
    id: "bio-11",
    title: "11-sinf Biologiya (Evolutsiya va Ekologiya)",
    sinf: 11,
    icon: "🌍",
    color: "#0891b2",
    description: "Darvin ta'limoti, tabiiy tanlanish, biotsenoz va biosfera qonuniyatlari",
    topics: [
      {
        id: "bio-11-1",
        title: "Evolutsiya omillari va dalillari",
        desc: "Mutatsiya, yashash uchun kurash, tabiiy tanlanish, gomologik va analogik organlar",
        visualType: "evolution_evidence",
        keyConcepts: ["Gomologik organlar", "Rudimentlar", "Atavizmlar", "Divergensiya", "Konvergensiya"]
      },
      {
        id: "bio-11-2",
        title: "Ekologik piramidalar va ozuqa zanjiri",
        desc: "Produtsentlar, konsumentlar, redutsentlar va 10 foizlik qoida",
        visualType: "ecological_pyramid",
        keyConcepts: ["Produtsent", "Konsument", "Redutsent", "Lindeman qoidasi", "Biomassa"]
      }
    ]
  }
];
