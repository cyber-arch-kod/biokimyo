// Foydalanuvchi natijalari, yulduzchalar va reyting tizimi
window.UserProgress = {
  KEY: "bio_chem_quiz_progress_v1",

  getProgress: function() {
    try {
      const data = localStorage.getItem(this.KEY);
      return data ? JSON.parse(data) : {
        completedTopics: {},
        stars: 0,
        xp: 0,
        streak: 1
      };
    } catch (e) {
      return { completedTopics: {}, stars: 0, xp: 0, streak: 1 };
    }
  },

  saveResult: function(topicId, percent, correct, total) {
    const p = this.getProgress();
    
    // Yulduzchalar hisobi (0-3 ta yulduz)
    let starsEarned = 0;
    if (percent >= 90) starsEarned = 3;
    else if (percent >= 70) starsEarned = 2;
    else if (percent >= 50) starsEarned = 1;

    const oldRecord = p.completedTopics[topicId] || { bestPercent: 0, stars: 0 };
    
    const newBest = Math.max(oldRecord.bestPercent, percent);
    const starDiff = Math.max(0, starsEarned - oldRecord.stars);

    p.stars += starDiff;
    p.xp += correct * 10;
    p.completedTopics[topicId] = {
      bestPercent: newBest,
      stars: Math.max(oldRecord.stars, starsEarned),
      lastTested: new Date().toISOString()
    };

    try {
      localStorage.setItem(this.KEY, JSON.stringify(p));
    } catch (e) {
      console.warn("Storage save failed", e);
    }

    // UI yangilash
    this.updateHeaderStats();
  },

  getTopicStats: function(topicId) {
    const p = this.getProgress();
    return p.completedTopics[topicId] || { bestPercent: 0, stars: 0 };
  },

  updateHeaderStats: function() {
    const p = this.getProgress();
    const starEl = document.getElementById('stat-stars');
    const xpEl = document.getElementById('stat-xp');
    if (starEl) starEl.innerText = p.stars;
    if (xpEl) xpEl.innerText = p.xp;
  }
};
