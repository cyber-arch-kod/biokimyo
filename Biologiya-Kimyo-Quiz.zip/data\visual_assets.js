// Rasmli va interaktiv vizual sxemalar bazasi
window.VISUAL_ASSETS = {
  // Biologiya: O'simlik hujayrasi tuzilishi
  plant_cell: {
    title: "O'simlik hujayrasining mikroskopik tuzilishi",
    desc: "Sxemadagi organoidlarni bosing va ularning nomi hamda vazifasini o'rganing!",
    svg: `
      <svg viewBox="0 0 500 350" class="w-full h-auto max-h-72 select-none">
        <defs>
          <radialGradient id="cellGrad" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stop-color="#d1fae5"/>
            <stop offset="100%" stop-color="#a7f3d0"/>
          </radialGradient>
        </defs>
        <!-- Hujayra devori -->
        <polygon points="40,40 460,30 480,310 30,320" fill="url(#cellGrad)" stroke="#059669" stroke-width="8" rx="20"/>
        <!-- Plazmatik membrana -->
        <polygon points="50,50 450,40 470,300 40,310" fill="none" stroke="#10b981" stroke-width="4" stroke-dasharray="6,4"/>
        <!-- Katta markaziy vakuola -->
        <ellipse cx="280" cy="180" rx="130" ry="85" fill="#bae6fd" stroke="#0284c7" stroke-width="3" class="interactive-part" data-part="vakuola" cursor="pointer"/>
        <text x="280" y="185" font-size="14" font-weight="bold" fill="#0369a1" text-anchor="middle" pointer-events="none">Vakuola (Hujayra shirasi)</text>
        <!-- Yadro -->
        <circle cx="130" cy="130" r="45" fill="#fbcfe8" stroke="#db2777" stroke-width="4" class="interactive-part" data-part="yadro" cursor="pointer"/>
        <circle cx="130" cy="130" r="16" fill="#be185d"/>
        <text x="130" y="135" font-size="12" font-weight="bold" fill="#ffffff" text-anchor="middle" pointer-events="none">Yadrocha</text>
        <!-- Xloroplastlar -->
        <ellipse cx="100" cy="240" rx="35" ry="22" fill="#22c55e" stroke="#15803d" stroke-width="3" class="interactive-part" data-part="xloroplast" cursor="pointer" transform="rotate(-15 100 240)"/>
        <ellipse cx="400" cy="100" rx="32" ry="20" fill="#22c55e" stroke="#15803d" stroke-width="3" class="interactive-part" data-part="xloroplast" cursor="pointer" transform="rotate(25 400 100)"/>
        <!-- Mitoxondriyalar -->
        <ellipse cx="200" cy="80" rx="28" ry="16" fill="#fb923c" stroke="#c2410c" stroke-width="3" class="interactive-part" data-part="mitoxondriya" cursor="pointer" transform="rotate(20 200 80)"/>
        <path d="M 182,80 Q 200,68 218,80" fill="none" stroke="#ffffff" stroke-width="2"/>
        <!-- Golji apparati -->
        <path d="M 80,80 Q 90,65 100,80 M 75,90 Q 90,75 105,90" fill="none" stroke="#8b5cf6" stroke-width="4" stroke-linecap="round" class="interactive-part" data-part="golji" cursor="pointer"/>
        <!-- Sitoplazma yozuvi -->
        <text x="70" y="295" font-size="13" font-weight="bold" fill="#047857" class="interactive-part" data-part="sitoplazma" cursor="pointer">Sitoplazma (Sitozol)</text>
      </svg>
    `,
    parts: {
      vakuola: {
        name: "Markaziy vakuola",
        func: "Hujayra shirasi bilan to'lgan bo'lib, turgor bosimini ta'minlaydi, organik moddalar va suvni saqlaydi."
      },
      yadro: {
        name: "Hujayra yadrosi va yadrocha",
        func: "Irsiy axborot (DNK) saqlovchisi, hujayra bo'linishi va barcha hayotiy jarayonlarini boshqaruvchi markaz."
      },
      xloroplast: {
        name: "Xloroplast (Plastida)",
        func: "Tarkibida xlorofill pigmenti bo'lib, fotosintez jarayonida quyosh nuri energiyasidan organik modda sintezlaydi."
      },
      mitoxondriya: {
        name: "Mitoxondriya (Hujayra elektr stansiyasi)",
        func: "Oziq moddalarni kislorod yordamida parchalab, ATF (energiya) hosil qiluvchi organoid."
      },
      golji: {
        name: "Golji apparati",
        func: "Moddalarni to'plash, o'zgartirish, qadoqlash va hujayradan chiqarish vazifasini bajaradi."
      },
      sitoplazma: {
        name: "Sitoplazma",
        func: "Hujayra ichki muhiti, barcha organoidlarni birlashtirib turadi va biokimyoviy reaksiyalar sodir bo'ladigan asosiy muhit."
      }
    }
  },

  // Biologiya: Odam yuragi va qon aylanishi
  heart_anatomy: {
    title: "Inson yuragining ichki tuzilishi va qon oqimi",
    desc: "Yurak bo'limlarini bosib, qon qayerdan kirib qayerga haydalishini bilib oling!",
    svg: `
      <svg viewBox="0 0 500 350" class="w-full h-auto max-h-72 select-none">
        <!-- Aorta -->
        <path d="M 230,120 C 230,50 310,40 330,90 L 310,120 Z" fill="#ef4444" stroke="#b91c1c" stroke-width="3" class="interactive-part" data-part="aorta" cursor="pointer"/>
        <text x="280" y="65" font-size="12" font-weight="bold" fill="#7f1d1d">Aorta qon tomiri</text>
        <!-- O'pka arteriyasi -->
        <path d="M 270,120 C 270,70 190,60 170,100 L 190,130 Z" fill="#3b82f6" stroke="#1d4ed8" stroke-width="3" class="interactive-part" data-part="opka_art" cursor="pointer"/>
        <!-- Yurak asosiy korpusi -->
        <path d="M 250,330 C 120,250 120,130 200,130 C 230,130 250,150 250,150 C 250,150 270,130 300,130 C 380,130 380,250 250,330 Z" fill="#fecaca" stroke="#dc2626" stroke-width="4"/>
        <!-- O'ng bo'lmacha (venoz) -->
        <rect x="150" y="150" width="80" height="60" rx="10" fill="#93c5fd" stroke="#1e40af" stroke-width="2" class="interactive-part" data-part="ong_bolmacha" cursor="pointer"/>
        <text x="190" y="185" font-size="11" font-weight="bold" fill="#1e3a8a" text-anchor="middle">O'ng bo'lmacha</text>
        <!-- Chap bo'lmacha (arterial) -->
        <rect x="270" y="150" width="80" height="60" rx="10" fill="#fca5a5" stroke="#991b1b" stroke-width="2" class="interactive-part" data-part="chap_bolmacha" cursor="pointer"/>
        <text x="310" y="185" font-size="11" font-weight="bold" fill="#7f1d1d" text-anchor="middle">Chap bo'lmacha</text>
        <!-- O'ng qorincha -->
        <rect x="160" y="225" width="80" height="75" rx="12" fill="#60a5fa" stroke="#1d4ed8" stroke-width="2" class="interactive-part" data-part="ong_qorincha" cursor="pointer"/>
        <text x="200" y="265" font-size="11" font-weight="bold" fill="#1e3a8a" text-anchor="middle">O'ng qorincha</text>
        <!-- Chap qorincha (qalin devorli) -->
        <rect x="260" y="225" width="85" height="85" rx="12" fill="#f87171" stroke="#b91c1c" stroke-width="3" class="interactive-part" data-part="chap_qorincha" cursor="pointer"/>
        <text x="302" y="270" font-size="11" font-weight="bold" fill="#7f1d1d" text-anchor="middle">Chap qorincha</text>
      </svg>
    `,
    parts: {
      chap_qorincha: {
        name: "Chap qorincha (Eng qalin muskul devorli)",
        func: "Katta qon aylanish doirasini boshlaydi. Kislorodga boy arterial qonni butun tanaga (Aortaga) kuchli bosim bilan haydaydi."
      },
      ong_qorincha: {
        name: "O'ng qorincha",
        func: "Kichik qon aylanish doirasini boshlaydi. Karbonat angidridga boy venoz qonni o'pka arteriyasi orqali o'pkalarga yo'naltiradi."
      },
      chap_bolmacha: {
        name: "Chap bo'lmacha",
        func: "Kichik qon aylanish doirasi shu yerda tugaydi. O'pka venalari orqali toza arterial qonni qabul qiladi."
      },
      ong_bolmacha: {
        name: "O'ng bo'lmacha",
        func: "Katta qon aylanish doirasi shu yerda tugaydi. Tana a'zolaridan yuqori va pastki kovak venalar orqali venoz qonni qabul qiladi."
      },
      aorta: {
        name: "Aorta qon tomiri",
        func: "Inson tanasidagi eng katta arterial qon tomiri bo'lib, kislorodli qonni yurakdan butun a'zo va to'qimalarga tarqatadi."
      },
      opka_art: {
        name: "O'pka arteriyasi",
        func: "Nomiga qaramay venoz qon tashiydigan noyob arteriya; qonni o'pkalarga kislorod bilan to'yinish uchun olib boradi."
      }
    }
  },

  // Kimyo: Atom tuzilishi va elektron qavatlari
  periodic_table_atom: {
    title: "Atomning planetar tuzilishi va element zarrachalari",
    desc: "Yadro va elektron qavatlarini bosib atom ichki mexanizmini kashf eting!",
    svg: `
      <svg viewBox="0 0 500 350" class="w-full h-auto max-h-72 select-none">
        <!-- 3-qavat orbita -->
        <ellipse cx="250" cy="175" rx="190" ry="140" fill="none" stroke="#cbd5e1" stroke-width="2" stroke-dasharray="5,5"/>
        <!-- 2-qavat orbita -->
        <ellipse cx="250" cy="175" rx="130" ry="95" fill="none" stroke="#94a3b8" stroke-width="2" stroke-dasharray="5,5"/>
        <!-- 1-qavat orbita -->
        <ellipse cx="250" cy="175" rx="70" ry="50" fill="none" stroke="#64748b" stroke-width="2"/>
        <!-- Yadro -->
        <circle cx="250" cy="175" r="32" fill="#ef4444" stroke="#b91c1c" stroke-width="3" class="interactive-part" data-part="atom_yadro" cursor="pointer"/>
        <text x="250" y="179" font-size="12" font-weight="bold" fill="#ffffff" text-anchor="middle" pointer-events="none">Yadro (p+ va n0)</text>
        <!-- Elektronlar 1-qavat -->
        <circle cx="250" cy="125" r="9" fill="#3b82f6" stroke="#1d4ed8" stroke-width="2" class="interactive-part" data-part="elektron_1" cursor="pointer"/>
        <text x="250" y="129" font-size="10" font-weight="bold" fill="#ffffff" text-anchor="middle" pointer-events="none">e⁻</text>
        <circle cx="250" cy="225" r="9" fill="#3b82f6" stroke="#1d4ed8" stroke-width="2" class="interactive-part" data-part="elektron_1" cursor="pointer"/>
        <text x="250" y="229" font-size="10" font-weight="bold" fill="#ffffff" text-anchor="middle" pointer-events="none">e⁻</text>
        <!-- Elektronlar 2-qavat -->
        <circle cx="120" cy="175" r="9" fill="#3b82f6" stroke="#1d4ed8" stroke-width="2" class="interactive-part" data-part="elektron_tashqi" cursor="pointer"/>
        <text x="120" y="179" font-size="10" font-weight="bold" fill="#ffffff" text-anchor="middle" pointer-events="none">e⁻</text>
        <circle cx="380" cy="175" r="9" fill="#3b82f6" stroke="#1d4ed8" stroke-width="2" class="interactive-part" data-part="elektron_tashqi" cursor="pointer"/>
        <text x="380" y="179" font-size="10" font-weight="bold" fill="#ffffff" text-anchor="middle" pointer-events="none">e⁻</text>
      </svg>
    `,
    parts: {
      atom_yadro: {
        name: "Atom Yadrosi (Protonlar va Neytronlar)",
        func: "Atom markazida joylashgan bo'lib, atomning deyarli butun massasini (99.9%) tashkil etadi. Musbat zaryadli protonlar (p+) va zaryadsiz neytronlardan (n0) iborat."
      },
      elektron_1: {
        name: "Ichki elektron qavati (1s orbital)",
        func: "Maksimal 2 ta elektron sig'dira oladi. Yadroga eng yaqin va eng past energiya darajasiga ega barqaror qavat."
      },
      elektron_tashqi: {
        name: "Tashqi valent elektronlar",
        func: "Kimyoviy reaksiyalarda ishtirok etuvchi, kimyoviy bog'lanishlarni hosil qiluvchi va moddaning xossalarini belgilovchi elektronlar."
      }
    }
  },

  // Kimyo: Laboratoriya jihozlari va idishlari
  mixtures_separation: {
    title: "Kimyoviy laboratoriya idishlari va ajratish apparatlari",
    desc: "Laboratoriya anjomlarini bosib ularning aniq vazifasini o'rganing!",
    svg: `
      <svg viewBox="0 0 500 350" class="w-full h-auto max-h-72 select-none">
        <!-- Spirt chiroq -->
        <path d="M 60,300 L 120,300 L 105,240 L 75,240 Z" fill="#94a3b8" stroke="#475569" stroke-width="2" class="interactive-part" data-part="spirt_chiroq" cursor="pointer"/>
        <path d="M 90,240 L 90,225" stroke="#f59e0b" stroke-width="4"/>
        <path d="M 90,225 C 80,205 100,195 90,180 C 80,195 100,205 90,225 Z" fill="#ef4444"/>
        <text x="90" y="325" font-size="11" font-weight="bold" fill="#334155" text-anchor="middle">Spirt chiroq</text>
        <!-- Shtativ -->
        <rect x="200" y="50" width="8" height="250" fill="#475569"/>
        <rect x="150" y="300" width="110" height="15" fill="#334155" rx="3"/>
        <rect x="208" y="140" width="60" height="6" fill="#64748b"/>
        <!-- Probirka shtativda -->
        <rect x="255" y="100" width="22" height="90" rx="10" fill="#e0f2fe" stroke="#0284c7" stroke-width="2" class="interactive-part" data-part="probirka" cursor="pointer"/>
        <rect x="257" y="145" width="18" height="40" rx="8" fill="#38bdf8"/>
        <text x="266" y="215" font-size="11" font-weight="bold" fill="#0369a1" text-anchor="middle">Probirka</text>
        <!-- Kolba (Konus shaklidagi Erlenmeyer kolbasi) -->
        <path d="M 370,160 L 390,160 L 390,190 L 430,290 L 330,290 L 370,190 Z" fill="#f0fdf4" stroke="#16a34a" stroke-width="3" class="interactive-part" data-part="erlenmeyer_kolba" cursor="pointer"/>
        <path d="M 345,260 L 415,260 L 425,285 L 335,285 Z" fill="#86efac"/>
        <text x="380" y="315" font-size="11" font-weight="bold" fill="#15803d" text-anchor="middle">Konus kolba</text>
      </svg>
    `,
    parts: {
      spirt_chiroq: {
        name: "Spirt chiroq (Qizdirish asbobi)",
        func: "Kimyoviy reaksiyalarni qizdirish, moddalarni parchalash va qaynatishda xavfsiz ochiq olov manbai sifatida ishlatiladi."
      },
      probirka: {
        name: "Probirka (Reaksiya idishi)",
        func: "Kichik hajmdagi moddalar bilan sifat reaksiyalarini o'tkazish, cho'kma hosil bo'lishini kuzatish uchun mo'ljallangan shisha idish."
      },
      erlenmeyer_kolba: {
        name: "Erlenmeyer kolbasi (Konus kolba)",
        func: "Titrlash jarayonlari, eritmalarni chayqatib aralashtirish va bug'lanishni kamaytirgan holda saqlash uchun ishlatiladi."
      }
    }
  }
};
