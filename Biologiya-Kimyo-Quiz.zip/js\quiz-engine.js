// Quiz dvijogi: 50 talik testlar, natijalar va tahlillar
window.QuizEngine = {
  currentQuiz: null,
  currentIndex: 0,
  userAnswers: [],
  timerInterval: null,
  timeElapsed: 0,
  onCompleteCallback: null,

  // Testni boshlash (topicId va savollar soni: 10, 25 yoki to'liq 50 ta)
  startQuiz: function(topicId, questionCount = 50, onComplete) {
    const allQuestions = window.getQuizForTopic(topicId);
    // Savollarni kerakli miqdorda olamiz
    const selectedQuestions = allQuestions.slice(0, questionCount);

    this.currentQuiz = {
      topicId: topicId,
      questions: selectedQuestions,
      total: selectedQuestions.length
    };
    this.currentIndex = 0;
    this.userAnswers = new Array(selectedQuestions.length).fill(null);
    this.timeElapsed = 0;
    this.onCompleteCallback = onComplete;

    this.startTimer();
    this.renderCurrentQuestion();
  },

  startTimer: function() {
    if (this.timerInterval) clearInterval(this.timerInterval);
    this.timeElapsed = 0;
    const timerEl = document.getElementById('quiz-timer');
    this.timerInterval = setInterval(() => {
      this.timeElapsed++;
      const mins = Math.floor(this.timeElapsed / 60).toString().padStart(2, '0');
      const secs = (this.timeElapsed % 60).toString().padStart(2, '0');
      if (timerEl) timerEl.innerText = `${mins}:${secs}`;
    }, 1000);
  },

  stopTimer: function() {
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
      this.timerInterval = null;
    }
  },

  renderCurrentQuestion: function() {
    const qContainer = document.getElementById('quiz-question-box');
    if (!qContainer) return;

    const q = this.currentQuiz.questions[this.currentIndex];
    const curIdx = this.currentIndex;
    const total = this.currentQuiz.total;
    const userAnswer = this.userAnswers[curIdx];

    // Progress bar yangilash
    const progressPercent = Math.round(((curIdx + 1) / total) * 100);
    const progressEl = document.getElementById('quiz-progress-fill');
    if (progressEl) progressEl.style.width = `${progressPercent}%`;

    const progressText = document.getElementById('quiz-counter');
    if (progressText) progressText.innerText = `${curIdx + 1} / ${total}`;

    let html = `
      <div class="question-card p-4 sm:p-6 bg-white dark:bg-slate-800 rounded-3xl shadow-lg border border-slate-100 dark:border-slate-700 animate-fadeIn">
        <div class="flex items-center justify-between gap-2 mb-4">
          <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-300">
            📌 Savol № ${curIdx + 1}
          </span>
          <span class="text-xs text-slate-400 font-medium">
            Jami: ${total} ta quiz
          </span>
        </div>

        <h3 class="text-base sm:text-lg font-bold text-slate-900 dark:text-white mb-6 leading-relaxed">
          ${q.q}
        </h3>

        <!-- Variantlar ro'yxati -->
        <div class="space-y-3">
    `;

    const letters = ["A", "B", "C", "D"];
    q.options.forEach((opt, optIdx) => {
      let isSelected = userAnswer === optIdx;
      let btnClass = isSelected
        ? "border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200 shadow-sm"
        : "border-slate-200 dark:border-slate-700 hover:border-emerald-300 bg-white dark:bg-slate-800/80 text-slate-700 dark:text-slate-200";

      html += `
        <button onclick="QuizEngine.selectAnswer(${optIdx})" 
                class="w-full text-left p-3.5 sm:p-4 rounded-2xl border-2 transition-all duration-200 flex items-start gap-3 active:scale-[0.99] ${btnClass}">
          <span class="w-7 h-7 flex-shrink-0 flex items-center justify-center rounded-xl text-xs font-bold ${isSelected ? 'bg-emerald-600 text-white' : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'}">
            ${letters[optIdx]}
          </span>
          <span class="text-sm sm:text-base leading-snug pt-0.5">${opt}</span>
        </button>
      `;
    });

    html += `
        </div>

        <!-- Pastki navigatsiya tugmalari -->
        <div class="flex justify-between items-center mt-6 pt-4 border-t border-slate-100 dark:border-slate-700 gap-3">
          <button onclick="QuizEngine.prevQuestion()" 
                  class="px-4 py-2.5 rounded-xl text-sm font-semibold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-700 active:scale-95 ${curIdx === 0 ? 'opacity-40 pointer-events-none' : ''}">
            ⬅️ Oldingisi
          </button>
          
          ${curIdx === total - 1 
            ? `<button onclick="QuizEngine.finishQuiz()" class="px-6 py-2.5 rounded-xl text-sm font-bold bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-600/30 active:scale-95">
                🏁 Natijani ko'rish
               </button>`
            : `<button onclick="QuizEngine.nextQuestion()" class="px-5 py-2.5 rounded-xl text-sm font-bold bg-emerald-600 text-white shadow-md shadow-emerald-600/20 active:scale-95">
                Keyingisi ➡️
               </button>`
          }
        </div>
      </div>
    `;

    qContainer.innerHTML = html;
  },

  selectAnswer: function(optIdx) {
    this.userAnswers[this.currentIndex] = optIdx;
    this.renderCurrentQuestion();
  },

  nextQuestion: function() {
    if (this.currentIndex < this.currentQuiz.total - 1) {
      this.currentIndex++;
      this.renderCurrentQuestion();
    }
  },

  prevQuestion: function() {
    if (this.currentIndex > 0) {
      this.currentIndex--;
      this.renderCurrentQuestion();
    }
  },

  finishQuiz: function() {
    this.stopTimer();

    // Hisob-kitob
    let correctCount = 0;
    const questions = this.currentQuiz.questions;
    const resultsDetails = [];

    questions.forEach((q, idx) => {
      const isCorrect = this.userAnswers[idx] === q.correct;
      if (isCorrect) correctCount++;
      resultsDetails.push({
        question: q.q,
        userAnswer: this.userAnswers[idx] !== null ? q.options[this.userAnswers[idx]] : "Javob berilmadi",
        correctAnswer: q.options[q.correct],
        isCorrect: isCorrect,
        explain: q.explain
      });
    });

    const percent = Math.round((correctCount / questions.length) * 100);

    // Natijani saqlash
    window.UserProgress.saveResult(this.currentQuiz.topicId, percent, correctCount, questions.length);

    this.renderResults(correctCount, questions.length, percent, resultsDetails);
  },

  renderResults: function(correct, total, percent, details) {
    const qContainer = document.getElementById('quiz-question-box');
    if (!qContainer) return;

    let grade = "A'lo!";
    let gradeColor = "text-emerald-500";
    let medal = "🥇";

    if (percent < 60) {
      grade = "Yana takrorlash kerak";
      gradeColor = "text-amber-500";
      medal = "🥉";
    } else if (percent < 85) {
      grade = "Yaxshi natija!";
      gradeColor = "text-blue-500";
      medal = "🥈";
    }

    let html = `
      <div class="results-card p-6 bg-white dark:bg-slate-800 rounded-3xl shadow-xl border border-slate-100 dark:border-slate-700 animate-fadeIn text-center">
        <div class="text-5xl mb-2">${medal}</div>
        <h2 class="text-2xl font-black text-slate-800 dark:text-white mb-1">Sinov yakunlandi!</h2>
        <p class="text-sm ${gradeColor} font-bold mb-4">${grade}</p>

        <!-- Natijalar ko'rsatkichi -->
        <div class="grid grid-cols-3 gap-3 my-6 max-w-sm mx-auto">
          <div class="bg-emerald-50 dark:bg-emerald-950/40 p-3 rounded-2xl border border-emerald-200">
            <span class="block text-xl font-black text-emerald-600">${correct}</span>
            <span class="text-xs text-slate-500">To'g'ri</span>
          </div>
          <div class="bg-red-50 dark:bg-red-950/40 p-3 rounded-2xl border border-red-200">
            <span class="block text-xl font-black text-red-500">${total - correct}</span>
            <span class="text-xs text-slate-500">Noto'g'ri</span>
          </div>
          <div class="bg-indigo-50 dark:bg-indigo-950/40 p-3 rounded-2xl border border-indigo-200">
            <span class="block text-xl font-black text-indigo-600">${percent}%</span>
            <span class="text-xs text-slate-500">Samaradorlik</span>
          </div>
        </div>

        <div class="flex flex-col sm:flex-row gap-3 max-w-sm mx-auto mb-6">
          <button onclick="QuizEngine.startQuiz('${this.currentQuiz.topicId}', ${total})" 
                  class="flex-1 py-3 px-4 bg-emerald-600 text-white rounded-xl font-bold shadow-md shadow-emerald-600/30 active:scale-95">
            🔄 Qaytadan topshirish
          </button>
          <button onclick="window.App.showTopicView('${this.currentQuiz.topicId}')" 
                  class="flex-1 py-3 px-4 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-bold active:scale-95">
            🔙 Mavzuga qaytish
          </button>
        </div>

        <!-- Xatolar tahlili (accordion) -->
        <div class="text-left mt-8 pt-6 border-t border-slate-100 dark:border-slate-700">
          <h4 class="text-sm font-bold text-slate-800 dark:text-white uppercase tracking-wider mb-4 flex items-center gap-2">
            <span>📝</span> Savollar va tushuntirishlar tahlili:
          </h4>
          <div class="space-y-3 max-h-96 overflow-y-auto pr-1">
    `;

    details.forEach((item, idx) => {
      html += `
        <div class="p-3.5 rounded-2xl border ${item.isCorrect ? 'border-emerald-200 bg-emerald-50/50 dark:bg-emerald-950/20' : 'border-red-200 bg-red-50/50 dark:bg-red-950/20'}">
          <div class="flex items-start gap-2 mb-1">
            <span class="text-sm font-bold ${item.isCorrect ? 'text-emerald-600' : 'text-red-500'}">
              ${item.isCorrect ? '✅' : '❌'} ${idx + 1}-savol
            </span>
            <span class="text-xs text-slate-700 dark:text-slate-300 font-medium leading-snug">${item.question}</span>
          </div>
          <div class="text-xs ml-6 space-y-0.5">
            <p class="text-slate-500">Sizning javobingiz: <span class="${item.isCorrect ? 'text-emerald-600 font-bold' : 'text-red-600 font-semibold'}">${item.userAnswer}</span></p>
            ${!item.isCorrect ? `<p class="text-emerald-700 font-bold">To'g'ri javob: ${item.correctAnswer}</p>` : ''}
            <p class="text-slate-400 mt-1 italic">💡 Sharh: ${item.explain}</p>
          </div>
        </div>
      `;
    });

    html += `
          </div>
        </div>
      </div>
    `;

    qContainer.innerHTML = html;
  }
};
