// O'yinlar tizimi: Juftini top, Fleshkartlar va Rasmli topshiriqlar
window.GameSystem = {
  // 1. Juftliklar bazasi (Biologiya va Kimyo)
  pairsData: {
    bio: [
      { a: "Mitoxondriya", b: "ATF (energiya) sintezi", icon: "⚡" },
      { a: "Xloroplast", b: "Fotosintez va xlorofill", icon: "🌱" },
      { a: "Ribosoma", b: "Oqsil biosintezi", icon: "🔬" },
      { a: "Yadro", b: "Irsiy axborot (DNK)", icon: "🧬" },
      { a: "Vakuola", b: "Hujayra shirasi va turgor", icon: "💧" },
      { a: "Eritrotsitlar", b: "Kislorod tashuvchi qon hujayrasi", icon: "🩸" },
      { a: "Trombotsitlar", b: "Qon ivishini ta'minlash", icon: "🩹" },
      { a: "Leykotsitlar", b: "Immunitet va fagotsitoz", icon: "🛡️" }
    ],
    chem: [
      { a: "H (Vodorod)", b: "Eng yengil element (Ar=1)", icon: "🎈" },
      { a: "O (Kislorod)", b: "Nafas va yonish gazi (Ar=16)", icon: "🔥" },
      { a: "Fe (Temir)", b: "Gemoglobin yadrosi (Ar=56)", icon: "🔩" },
      { a: "Au (Oltin)", b: "Asil metall (Ar=197)", icon: "👑" },
      { a: "NaCl", b: "Osh tuzi", icon: "🧂" },
      { a: "H2O", b: "Suv (hayot manbai)", icon: "💧" },
      { a: "CH4", b: "Metan (tabiiy gaz)", icon: "⛽" },
      { a: "H2SO4", b: "Sulfat kislota", icon: "⚗️" }
    ]
  },

  // "Juftini top" o'yinini ishga tushirish
  initMatchingGame: function(containerId, subject = 'bio') {
    const container = document.getElementById(containerId);
    if (!container) return;

    const data = this.pairsData[subject] || this.pairsData.bio;
    // 6 ta juftlik tanlaymiz (jami 12 ta karta telefonga eng mos o'lcham)
    const selectedPairs = data.slice(0, 6);
    
    let cards = [];
    selectedPairs.forEach((pair, idx) => {
      cards.push({ id: idx, text: pair.a, type: 'a', icon: pair.icon });
      cards.push({ id: idx, text: pair.b, type: 'b', icon: pair.icon });
    });

    // Kartalarni aralashtirish
    cards.sort(() => Math.random() - 0.5);

    let html = `
      <div class="matching-game-wrapper p-3">
        <div class="flex justify-between items-center mb-4 bg-emerald-50 dark:bg-emerald-950 p-3 rounded-xl border border-emerald-200">
          <span class="text-emerald-800 dark:text-emerald-300 font-semibold text-sm">🎯 Topilgan juftliklar: <span id="match-score">0</span> / 6</span>
          <span class="text-emerald-700 dark:text-emerald-400 font-semibold text-sm">⏱️ Urinishlar: <span id="match-moves">0</span></span>
        </div>
        <div class="grid grid-cols-3 sm:grid-cols-4 gap-2.5" id="cards-grid">
    `;

    cards.forEach((card, index) => {
      html += `
        <div class="game-card h-24 sm:h-28 p-2 rounded-xl bg-white dark:bg-slate-800 shadow-md border-2 border-slate-200 dark:border-slate-700 flex flex-col items-center justify-center text-center cursor-pointer transition-all duration-300 transform active:scale-95 hover:border-emerald-500" 
             data-index="${index}" data-id="${card.id}" onclick="GameSystem.handleCardClick(${index})">
          <span class="text-xl mb-1">${card.icon}</span>
          <span class="text-xs sm:text-sm font-medium text-slate-800 dark:text-slate-100 leading-tight">${card.text}</span>
        </div>
      `;
    });

    html += `
        </div>
        <div id="game-win-banner" class="hidden mt-4 p-4 bg-green-100 text-green-800 rounded-xl text-center font-bold">
          🎉 Qoyilmaqom! Barcha juftliklarni muvaffaqiyatli topdingiz!
          <button onclick="GameSystem.initMatchingGame('${containerId}', '${subject}')" class="mt-2 block w-full py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700">Qayta o'ynash</button>
        </div>
      </div>
    `;

    container.innerHTML = html;

    this.gameState = {
      cards: cards,
      firstCard: null,
      lock: false,
      matched: 0,
      moves: 0,
      containerId: containerId,
      subject: subject
    };
  },

  handleCardClick: function(index) {
    const state = this.gameState;
    if (state.lock) return;

    const cardElements = document.querySelectorAll('#cards-grid .game-card');
    const clickedEl = cardElements[index];

    if (clickedEl.classList.contains('matched') || clickedEl.classList.contains('selected')) {
      return;
    }

    clickedEl.classList.add('selected', 'border-emerald-600', 'bg-emerald-50');

    if (!state.firstCard) {
      state.firstCard = { index: index, data: state.cards[index], el: clickedEl };
      return;
    }

    // Ikkinchi karta tanlandi
    state.moves++;
    document.getElementById('match-moves').innerText = state.moves;

    const first = state.firstCard;
    const second = { index: index, data: state.cards[index], el: clickedEl };

    if (first.data.id === second.data.id && first.index !== second.index) {
      // Juftlik to'g'ri topildi!
      state.matched++;
      document.getElementById('match-score').innerText = state.matched;
      first.el.classList.remove('selected', 'border-emerald-600', 'bg-emerald-50');
      second.el.classList.remove('selected', 'border-emerald-600', 'bg-emerald-50');

      first.el.classList.add('matched', 'border-green-500', 'bg-green-100', 'opacity-60', 'pointer-events-none');
      second.el.classList.add('matched', 'border-green-500', 'bg-green-100', 'opacity-60', 'pointer-events-none');

      state.firstCard = null;

      if (state.matched === 6) {
        document.getElementById('game-win-banner').classList.remove('hidden');
      }
    } else {
      // Noto'g'ri juftlik
      state.lock = true;
      first.el.classList.add('border-red-500', 'bg-red-50');
      second.el.classList.add('border-red-500', 'bg-red-50');

      setTimeout(() => {
        first.el.classList.remove('selected', 'border-emerald-600', 'bg-emerald-50', 'border-red-500', 'bg-red-50');
        second.el.classList.remove('selected', 'border-emerald-600', 'bg-emerald-50', 'border-red-500', 'bg-red-50');
        state.firstCard = null;
        state.lock = false;
      }, 700);
    }
  },

  // 2. Fleshkartlar tizimi (Karta ustiga bosganda ag'dariladi)
  initFlashcards: function(containerId, topicId) {
    const container = document.getElementById(containerId);
    if (!container) return;

    const questions = window.getQuizForTopic(topicId);
    // 15 ta fleshkarta qilib olamiz
    const flashList = questions.slice(0, 15);
    let currentIndex = 0;

    const renderCard = (idx) => {
      const q = flashList[idx];
      const correctText = q.options[q.correct];

      container.innerHTML = `
        <div class="flashcard-container p-4 flex flex-col items-center">
          <div class="w-full flex justify-between items-center mb-3 text-sm text-slate-500 font-semibold">
            <span>Karta: ${idx + 1} / ${flashList.length}</span>
            <span class="text-emerald-600">💡 Kartani bosing va javobni tekshiring</span>
          </div>

          <!-- Ag'dariluvchi karta -->
          <div id="flashcard-box" class="w-full max-w-sm h-64 bg-gradient-to-br from-emerald-500 to-teal-700 text-white rounded-3xl p-6 shadow-xl cursor-pointer flex flex-col justify-between transition-transform duration-500 transform text-center relative select-none">
            <div class="flex justify-between items-center text-xs opacity-75">
              <span>SAVOL</span>
              <span>🔄 Ag'darish uchun bosing</span>
            </div>
            
            <div id="flashcard-front" class="my-auto">
              <p class="text-lg font-bold leading-snug">${q.q}</p>
            </div>

            <div id="flashcard-back" class="hidden my-auto">
              <p class="text-xs uppercase tracking-wider text-emerald-200 mb-2">To'g'ri javob:</p>
              <p class="text-xl font-extrabold text-white mb-2">${correctText}</p>
              <p class="text-xs text-emerald-100 opacity-90">${q.explain}</p>
            </div>

            <div class="text-xs opacity-75">
              ${q.concept ? `Tushuncha: ${q.concept}` : 'Biologiya va Kimyo'}
            </div>
          </div>

          <!-- Boshqaruv tugmalari -->
          <div class="flex gap-3 mt-6 w-full max-w-sm">
            <button id="btn-prev-card" class="flex-1 py-3 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-100 rounded-2xl font-bold active:scale-95 transition-all ${idx === 0 ? 'opacity-40 pointer-events-none' : ''}">
              ⬅️ Oldingisi
            </button>
            <button id="btn-flip-card" class="flex-1 py-3 bg-emerald-600 text-white rounded-2xl font-bold active:scale-95 shadow-md shadow-emerald-600/30">
              🔄 Javobni ko'rish
            </button>
            <button id="btn-next-card" class="flex-1 py-3 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-100 rounded-2xl font-bold active:scale-95 transition-all ${idx === flashList.length - 1 ? 'opacity-40 pointer-events-none' : ''}">
              Keyingisi ➡️
            </button>
          </div>
        </div>
      `;

      // Listenerlar
      const cardBox = document.getElementById('flashcard-box');
      const front = document.getElementById('flashcard-front');
      const back = document.getElementById('flashcard-back');
      let isFlipped = false;

      const toggleFlip = () => {
        isFlipped = !isFlipped;
        if (isFlipped) {
          front.classList.add('hidden');
          back.classList.remove('hidden');
          cardBox.classList.remove('from-emerald-500', 'to-teal-700');
          cardBox.classList.add('from-indigo-600', 'to-purple-800');
        } else {
          front.classList.remove('hidden');
          back.classList.add('hidden');
          cardBox.classList.remove('from-indigo-600', 'to-purple-800');
          cardBox.classList.add('from-emerald-500', 'to-teal-700');
        }
      };

      cardBox.onclick = toggleFlip;
      document.getElementById('btn-flip-card').onclick = toggleFlip;

      document.getElementById('btn-prev-card').onclick = () => {
        if (currentIndex > 0) {
          currentIndex--;
          renderCard(currentIndex);
        }
      };

      document.getElementById('btn-next-card').onclick = () => {
        if (currentIndex < flashList.length - 1) {
          currentIndex++;
          renderCard(currentIndex);
        }
      };
    };

    renderCard(0);
  }
};
