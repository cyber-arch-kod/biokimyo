const CACHE_NAME = 'bio-chem-quiz-v1';
const ASSETS_TO_CACHE = [
  './',
  './index.html',
  './css/style.css',
  './data/biology_books.js',
  './data/chemistry_books.js',
  './data/visual_assets.js',
  './data/quiz_bank.js',
  './data/games.js',
  './js/storage.js',
  './js/quiz-engine.js',
  './js/app.js',
  './manifest.json'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE);
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((response) => {
      return response || fetch(event.request).catch(() => caches.match('./index.html'));
    })
  );
});
